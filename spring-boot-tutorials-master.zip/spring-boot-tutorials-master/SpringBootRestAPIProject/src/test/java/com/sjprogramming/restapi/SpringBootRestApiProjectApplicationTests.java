package com.sjprogramming.restapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootRestApiProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
